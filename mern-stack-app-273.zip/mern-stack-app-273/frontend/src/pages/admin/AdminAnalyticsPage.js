import AnalyticsPageComponent from "./components/AnalyticsPageComponent";

const AdminAnalyticsPage = () => {
  return <AnalyticsPageComponent />;
};

export default AdminAnalyticsPage;

