const AdminChatRoomComponent = () => {
  return <p>AdminChatRoomComponent</p>;
};

export default AdminChatRoomComponent;

