import CreateProductPageComponent from "./components/CreateProductPageComponent";

const AdminCreateProductPage = () => {
  
  return <CreateProductPageComponent />;
};

export default AdminCreateProductPage;

