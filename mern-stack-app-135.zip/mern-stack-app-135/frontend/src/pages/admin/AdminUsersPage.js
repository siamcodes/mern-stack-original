import UsersPageComponent from "./components/UsersPageComponent";

const AdminUsersPage = () => {
  return <UsersPageComponent />;
};

export default AdminUsersPage;

