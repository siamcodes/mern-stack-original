import HomePageComponent from "./components/HomePageComponent";

const HomePage = () => {

  return <HomePageComponent />;
};

export default HomePage;

