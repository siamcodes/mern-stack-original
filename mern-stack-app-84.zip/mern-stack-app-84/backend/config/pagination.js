const recordsPerPage = 2
module.exports = recordsPerPage
