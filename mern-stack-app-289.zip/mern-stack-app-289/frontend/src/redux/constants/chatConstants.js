export const SET_CHATROOMS = "SET_CHATROOMS";
export const SET_SOCKET = "SET_SOCKET";
