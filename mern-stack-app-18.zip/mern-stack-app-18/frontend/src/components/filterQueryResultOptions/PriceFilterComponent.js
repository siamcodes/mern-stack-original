import { Form } from "react-bootstrap";

const PriceFilterComponent = () => {
  return (
    <>
      <Form.Label>Range</Form.Label>
      <Form.Range />
    </>
  );
};

export default PriceFilterComponent;
