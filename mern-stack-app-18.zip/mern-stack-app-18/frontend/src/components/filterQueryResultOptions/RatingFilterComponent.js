const RatingFilterComponent = () => {
  return (
   <p>RatingFilterComponent</p>
  );
};

export default RatingFilterComponent;
