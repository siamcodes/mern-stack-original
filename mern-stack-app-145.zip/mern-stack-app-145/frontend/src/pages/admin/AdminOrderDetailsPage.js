import OrderDetailsPageComponent from './components/OrderDetailsPageComponent'

const AdminOrderDetailsPage = () => {
  return <OrderDetailsPageComponent />
};

export default AdminOrderDetailsPage;

