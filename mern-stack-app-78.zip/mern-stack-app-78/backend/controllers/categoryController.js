
const getCategories = (req, res) => {
    res.send("Handling category routes, e.g. get all categories")
}
module.exports = getCategories
