
const getOrders = (req, res) => {
    res.send("Handling order routes, e.g. get orders")
}
module.exports = getOrders
