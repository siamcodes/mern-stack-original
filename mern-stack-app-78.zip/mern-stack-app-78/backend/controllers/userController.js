
const getUsers = (req, res) => {
    res.send("Handling user routes, e.g. get users")
}
module.exports = getUsers
